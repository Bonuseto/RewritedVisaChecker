package model;

public enum VisaStatus {
    APPROVED,
    IN_PROGRESS,
    DENIED
}
