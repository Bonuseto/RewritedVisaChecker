# VisaCzecker
Programm for checking status of visa-application in Czech Republic
